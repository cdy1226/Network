#include <WinSock2.h>
#include <WS2tcpip.h>
#include <stdio.h>
#include <Windows.h>
#pragma comment(lib, "ws2_32.lib")

#define MAX_BUF 100
#define MAX_CLIENT 50

SOCKET client[MAX_CLIENT];

DWORD WINAPI thread_for_client(LPVOID pParam)
{
	int idx = (int)pParam;
	SOCKET t = client[idx];

	char chRxBuf[MAX_BUF] = { 0 };
	while (1)
	{
		int iLength = recv(t, chRxBuf, MAX_BUF, 0);
		
		chRxBuf[iLength] = NULL;
		printf("%s\n", chRxBuf);

		for (int i = 0; i < MAX_CLIENT;i++)
		{
			if ((client[i] != 0) && (client[i] != t))
			{
				send(client[i], chRxBuf, strlen(chRxBuf), 0);
				printf("%s\n", chRxBuf);
			}
	
		}
		
	}
	client[idx] = 0;
	closesocket(t);
	return 0;
}



int main(void)
{
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Error in starting up Winsock\n");
		return -1;
	}


	SOCKET s = socket(AF_INET, SOCK_STREAM, 0);
	if (s == INVALID_SOCKET)
	{
		printf("Error in socket(), Error code : %d\n", WSAGetLastError());
		WSACleanup();
		return -1;
	}

	SOCKADDR_IN myAddress;
	ZeroMemory(&myAddress, sizeof(myAddress));
	myAddress.sin_family = AF_INET;
	myAddress.sin_port = htons(50000);
	myAddress.sin_addr.s_addr = INADDR_ANY;
	bind(s, (SOCKADDR*)&myAddress, sizeof(myAddress));
	
	listen(s, 5);



	while (1)
	{
		SOCKADDR_IN clientAddress;
		int iAddressLength = sizeof(clientAddress);
		SOCKET t = accept(s, (SOCKADDR*)&clientAddress, &iAddressLength);
		int idx = -1;
		for (int i = 0; i < MAX_CLIENT; i++)
		{
			if (client[i] == 0)
			{
				idx = i;
				break;
			}
		}

		if (idx >= 0)
		{
			client[idx] = t;
			CreateThread(NULL, 0, thread_for_client, (LPVOID)idx, 0, NULL);

		}
	

	}
	closesocket(s);

	WSACleanup();

	return 0;
}