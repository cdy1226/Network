#include <WinSock2.h>
#include <WS2tcpip.h>
#include <stdio.h>
#include <Windows.h>
#pragma comment(lib, "ws2_32.lib")


#define MAX_BUF 100

DWORD WINAPI thread_for_display(LPVOID pParam) //�ҽÿ� ���ƿ��� �޼��� Ȯ��
{
	SOCKET s = (SOCKET)pParam;

	char chRxBuf[MAX_BUF] = { 0 };
	while (1)
	{
		int iLength = recv(s, chRxBuf, MAX_BUF - 1, 0);
		chRxBuf[iLength] = NULL;
		printf("%s\n", chRxBuf);//�ʼ�
	}
	closesocket(s);
	return 0;
}

int main(void)
{
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Error in starting up Winsock\n");
		return -1;
	}


	SOCKET s = socket(AF_INET, SOCK_STREAM, 0);
	if (s == INVALID_SOCKET)
	{
		printf("Error in socket(), Error code : %d\n", WSAGetLastError());
		WSACleanup();
		return -1;
	}

	SOCKADDR_IN serverAddress;
	ZeroMemory(&serverAddress, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_port = htons(50000);
	inet_pton(AF_INET, "165.229.125.45", &(serverAddress.sin_addr.s_addr));

	connect(s, (SOCKADDR*)&serverAddress, sizeof(serverAddress));

	CreateThread(NULL, 0, thread_for_display, (LPVOID)s, 0, NULL);

	while (1)
	{
		char chTxBuf[MAX_BUF] = { 0 };
		if (gets_s(chTxBuf, MAX_BUF - 1) != NULL)
		{
			send(s, chTxBuf, strlen(chTxBuf),0);
	
	
		
		}
		else
			break;
	}

	closesocket(s);

	WSACleanup();

	return 0;
}