#include <WinSock2.h>
#include <WS2tcpip.h>
#include <stdio.h>
#include <time.h>
#pragma comment(lib, "ws2_32.lib")

#define MAX_BUF 100

int main(void)
{
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Error in starting up Winsock\n");
		return -1;
	}


	SOCKET s = socket(AF_INET, SOCK_STREAM, 0);
	if (s == INVALID_SOCKET)
	{
		printf("Error in socket(), Error code : %d\n", WSAGetLastError());
		WSACleanup();
		return -1;
	}

	SOCKADDR_IN myAddress;
	ZeroMemory(&myAddress, sizeof(myAddress));
	myAddress.sin_family = AF_INET;
	myAddress.sin_port = htons(50000);
	myAddress.sin_addr.s_addr = INADDR_ANY;
	bind(s, (SOCKADDR*)&myAddress, sizeof(myAddress));

	listen(s, 5);


	SOCKADDR_IN clientAddress;
	time_t current_time;
	time(&current_time);

	while (1)
	{
		SOCKADDR_IN clientAddress;
		int iAddressLength = sizeof(clientAddress);

		SOCKET t = accept(s, (SOCKADDR*)&clientAddress, &iAddressLength);
		
	
	
		char chRxBuf[MAX_BUF] = { 0 };
		int iLength = recv(t, chRxBuf, MAX_BUF, 0);
		printf("%s", chRxBuf);

		char chTxBuf[MAX_BUF] = "Hello, TCP Client! Current time is ...";
		send(t, chTxBuf, strlen(chTxBuf), 0);


	}
	closesocket(s);

	WSACleanup();

	return 0;
}